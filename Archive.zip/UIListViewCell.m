//
//  UIListViewCell.m
//  UIListView
//
//  Created by SeeKool on 11/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "UIListViewCell.h"

@implementation UIListViewCell

@synthesize imageView = _imageView;
@synthesize textLabel = _textLabel;
@synthesize detailTextLabel = _detailTextLabel;
@synthesize contentView = _contentView;
@synthesize backgroundView = _backgroundView;
@synthesize selectedBackgroundView = _selectedBackgroundView;
@synthesize reuseIdentifier = _reuseIdentifier;
@synthesize accessoryType = _accessoryType;
@synthesize accessoryView = _accessoryView;
@synthesize editingAccessoryType = _editingAccessoryType;
@synthesize editingAccessoryView = _editingAccessoryView;


#pragma mark -
#pragma mark - dealloc (Memory Manager)
- (void)dealloc
{
    [_imageView release];
    [_textLabel release];
    [_detailTextLabel release];
    [_contentView release];
    [_backgroundView release];
    [_selectedBackgroundView release];
    [_reuseIdentifier release];
    [_accessoryView release];
    [_editingAccessoryView release];
    
    [super dealloc];
}

#pragma mark -
#pragma mark - init
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (id)initWithStyle:(UIListViewCellStyle)style
{
    self = [super init];
    if (self) {
        switch (style) {
            case UIListViewCellStyleDefault:
            {
                
                
                break;
            }
            
            case UIListViewCellStyleSubtitle:
            {
                
                
                break;
            }
                
            default:
                break;
        }
    }
    
    return self;
}


#pragma mark -
#pragma mark - object methods
- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    
}

- (void)setHighlighted:(BOOL)highlighted animated:(BOOL)animated
{
    
}


#pragma mark -
#pragma mark - settings
- (void)setImageView:(UIImageView *)imageView
{
    
}


- (void)setTextLabel:(UILabel *)textLabel
{
    
}

@end
