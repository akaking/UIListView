//
//  UIListViewCell.h
//  UIListView
//
//  Created by SeeKool on 11/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    //  Simple cell with text label and optional image view.
    //  if image is not setted, only a left aligned text will be shown.
    //  if text is not setted, only a left image will be shown.
    UIListViewCellStyleDefault,
    //  Left aligned image on top, left aligned title label on the right of image and left aligned subtitle label on the right of image and on the bottom of title label.
    UIListViewCellStyleSubtitle,
} UIListViewCellStyle;


typedef enum {
    UIListViewCellAccessoryTypeNone,
    UIListViewCellAccessoryTypeOne,
    UIListViewCellSeperatorStyleTwo,
} UIListViewCellAccessoryType;


@interface UIListViewCell : UIView

- (id)initWithStyle:(UIListViewCellStyle)style;

//  Content. These properties provide direct access to the internal label and image views used by the list view cell.

//  default is nil. image view will be create if necessary.
@property (nonatomic, retain) UIImageView   *imageView;
//  default is nil. label will be created if necessary.
@property (nonatomic, retain) UILabel       *textLabel;
//  default is nil. label will be created if necessary (and the current style supports a detail label).
@property (nonatomic, retain) UILabel       *detailTextLabel;

//  If you want to customize cells by simple adding additional views, you should add them to the content view so they will be positioned appropriately as the cell transitions into and out of editing mode.
@property (nonatomic, retain) UIView        *contentView;

//  Default is nil for cells. The 'backgroundView' will be added as a subview behind all other views.
@property (nonatomic, retain) UIView        *backgroundView;

//  Default is nil for cells. The 'selectedBackgroundView' will be added as a subview directly above the backgroundView if not nil, or behind all other views. It is added as a subview only when the cell is selected. Calling -setSelected:animated: will cause the 'selectedBackgroundView' to animate in and out with an alpha fade.
@property (nonatomic, retain) UIView        *selectedBackgroundView;

@property (nonatomic, copy) NSString        *reuseIdentifier;

//  animate between regular and selected state
- (void)setSelected:(BOOL)selected animated:(BOOL)animated;
//  animate between regular and highlighed state
- (void)setHighlighted:(BOOL)highlighted animated:(BOOL)animated;


//  default is UIListViewCellAccessoryTypeNone
@property (nonatomic, assign) UIListViewCellAccessoryType   accessoryType;
//  if set, use custom view. ignore accessoryType.
@property (nonatomic, retain) UIView                        *accessoryView;
//  default is UIListViewCellAccessoryTypeNone
@property (nonatomic, assign) UIListViewCellAccessoryType   editingAccessoryType;
//  if set, use custom view. ignore accessoryType.
@property (nonatomic, retain) UIView                        *editingAccessoryView;


@end
